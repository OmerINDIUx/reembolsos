# Guía de Despliegue en Hostinger (Laravel)

Esta guía te ayudará a subir tu sistema de reembolsos a un servidor de Hostinger paso a paso, diseñado para que funcione de manera segura.

---

## 🏗️ Fase 1: Preparación Local (Lo que haces en tu computadora)

1. **Compilar el Diseño (Ya lo hice por ti):**
    - Acabo de ejecutar el comando `npm run build` en tu computadora para "empaquetar" todos los colores, estilos e imágenes para que pesen poco y carguen rápido en producción.
2. **Crear el Archivo Comprimido (ZIP):**
    - Ve a la carpeta de tu proyecto local (`c:\laragon\www\reembolsos`).
    - Selecciona **todos** los archivos y carpetas, EXCEPTO:
        - ❌ `node_modules` (esta carpeta es solo de desarrollo y pesa muchísimo).
        - ❌ `tests` (opcional).
    - **Es importante incluir las carpetas ocultas** como `.env` y el archivo `.gitattributes`.
    - Haz clic derecho y comprime todo en un archivo `.zip` (por ejemplo: `reembolsos_app.zip`).

---

## 🌐 Fase 2: Preparación en Hostinger (hPanel)

1. **Crear la Base de Datos:**
    - Inicia sesión en **hPanel** de Hostinger.
    - Ve a **Bases de Datos** > **Gestión de Bases de Datos**.
    - Crea una nueva Base de Datos, con Usuario y Contraseña.
    - 📌 **Guarda bien estos tres datos** (Nombre de BD, Usuario, Contraseña) los usaremos enseguida.

---

## 🚀 Fase 3: Subida del Proyecto y Configuración

1. **Subir los Archivos:**
    - Ve a la sección **Archivos** > **Administrador de Archivos** en hPanel.
    - Navega dentro de la carpeta principal de tu dominio (generalmente `public_html` si es el dominio principal, o una subcarpeta si es un subdominio).
    - **Sube** el archivo `reembolsos_app.zip` que creaste en el paso 1.
    - Haz clic derecho sobre el `.zip` y selecciona **Extraer** (Extract).
    - _Importante: Asegúrate de que los archivos principales como `app`, `public`, `routes`, etc., queden directamente en la raíz de tu dominio o carpeta destinada, y no anidados dentro de otra carpeta llamada "reembolsos"._
    - Una vez extraído, puedes borrar el archivo `.zip`.

2. **Ajustar el Archivo `.env` (Configuración):**
    - En ese mismo administrador de archivos, busca el archivo `.env` (si no lo ves, asegúrate de activar la vista de archivos ocultos en la configuración). Ábrelo para editarlo.
    - Cambia las siguientes variables para que coincidan con la base de datos que creaste en el paso 2:

        ```env
        APP_ENV=production
        APP_DEBUG=false
        APP_URL=https://tudominio.com

        DB_CONNECTION=mysql
        DB_HOST=127.0.0.1
        DB_PORT=3306
        DB_DATABASE=aqui_el_nombre_bd_hostinger
        DB_USERNAME=aqui_el_usuario_hostinger
        DB_PASSWORD=aqui_tu_contraseña_hostinger
        ```

    - Guarda los cambios.

---

## 🚪 Fase 4: Solucionar la Ruta de "Public" (El paso clave)

Laravel por seguridad "esconde" su código central y solo expone la carpeta `public/`. Sin embargo, Hostinger carga por defecto la carpeta `public_html/`. Para solucionarlo, haz lo siguiente:

1. **Crear regla de redirección (`.htaccess` en `public_html`):**
    - En tu **Administrador de Archivos**, directamente en la carpeta raíz (`public_html` o donde hayas extraído todo), vas a crear un NUEVO archivo llamado `.htaccess`.
    - Abre este nuevo `.htaccess` y pega el siguiente código para redirigir silenciosamente todo el tráfico hacia la carpeta `public`:

```apache
<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteRule ^(.*)$ public/$1 [L]
</IfModule>
```

- Guarda el archivo. Esto hará que al entrar a `tudominio.com` el servidor lea directamente lo que hay dentro de `public`.

---

## 💻 Fase 5: Levantar la Base de Datos (Vía Terminal/SSH)

Hostinger incluye una terminal (SSH) en la web, ideal para ejecutar comandos de Laravel.

1. **Abrir Terminal Web:**
    - En el menú lateral izquierdo de hPanel, ve a **Avanzado** > **Acceso SSH** o usa la **Terminal Web** de Hostinger en el Administrador de Archivos, dependiendo de tu plan.
    - Si usas la terminal basada en la web integrada (Web Terminal), ábrela.

2. **Navegar a tu Proyecto (si es necesario):**
    - Escribe el comando: `cd public_html` (o la ruta donde pusiste los archivos).

3. **Migrar la Base de Datos (Generar Tablas):**
    - Ejecuta: `php artisan migrate --force`
    - _Si te pregunta si estás seguro de correrlo en producción, dile que yes._
    - _(Nota: Si la base de datos estaba vacía, esto creará las tablas. Si quieres insertar el administrador por defecto desde cero, puedes correr `php artisan migrate:fresh --seed --force`)._

4. **Vincular Carpeta de Archivos de Reembolsos (Storage Link):**
    - Ejecuta: `php artisan storage:link`
    - **¡Muy Importante!** Sin esto, cuando los usuarios suban PDFs o facturas en Hostinger, el sistema no sabrá dónde mostrarlos o guardarlos públicamente en el panel.

5. **Limpiar Caché Final:**
    - Para que el servidor lea los últimos cambios frescos del `.env` y el enrutamiento general, corre:
    - `php artisan optimize:clear`
    - `php artisan config:cache`

---

## 🎉 Cierre

Tu sistema de Reembolsos debería estar completamente operativo si visitas tu dominio. ¡Cualquier carga de Facturas PDF, notificaciones y reglas de validación funcionarán como en tu ordenador local!
