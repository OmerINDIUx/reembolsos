<img src="{{ asset('images/GI-animado-completo.gif') }}" {{ $attributes }} alt="Logo" />
