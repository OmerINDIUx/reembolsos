<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            
            <!-- Welcome Section -->
            <div class="mb-6">
                <h3 class="text-2xl font-bold text-gray-800 dark:text-gray-200">Hola, <?php echo e(Auth::user()->name); ?> 👋</h3>
                <p class="text-gray-600 dark:text-gray-400">Bienvenido al sistema de Reimbursements.</p>
            </div>

            <!-- Stats Grid -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                
                <?php if(Auth::user()->isDirector()): ?>
                    <!-- Director Specific Stats -->
                    
                    <!-- Pending Approvals -->
                    <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg border-l-4 border-yellow-500">
                        <div class="p-6">
                            <div class="text-gray-500 dark:text-gray-400 text-sm font-medium uppercase tracking-wider">Por Aprobar</div>
                            <div class="mt-2 flex items-baseline">
                                <span class="text-3xl font-bold text-gray-900 dark:text-gray-100"><?php echo e($stats['pending_approvals_count'] ?? 0); ?></span>
                                <span class="ml-2 text-sm text-gray-500">Solicitudes</span>
                            </div>
                            <div class="mt-1 text-sm text-yellow-600 font-medium">
                                $<?php echo e(number_format($stats['pending_approvals_amount'] ?? 0, 2)); ?> Pendiente
                            </div>
                        </div>
                    </div>

                    <!-- My Pending Requests -->
                    <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg border-l-4 border-blue-500">
                        <div class="p-6">
                            <div class="text-gray-500 dark:text-gray-400 text-sm font-medium uppercase tracking-wider">Mis Solicitudes Pendientes</div>
                            <div class="mt-2 flex items-baseline">
                                <span class="text-3xl font-bold text-gray-900 dark:text-gray-100"><?php echo e($stats['my_pending_count'] ?? 0); ?></span>
                            </div>
                        </div>
                    </div>

                    <!-- My Corrections (Director) -->
                    <?php if(isset($stats['my_correction_count']) && $stats['my_correction_count'] > 0): ?>
                    <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg border-l-4 border-orange-500">
                        <div class="p-6">
                            <div class="text-gray-500 dark:text-gray-400 text-sm font-medium uppercase tracking-wider">Requieren Mi Corrección</div>
                            <div class="mt-2 flex items-baseline">
                                <span class="text-3xl font-bold text-gray-900 dark:text-gray-100"><?php echo e($stats['my_correction_count']); ?></span>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>

                    <!-- My Approved -->
                    <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg border-l-4 border-green-500">
                        <div class="p-6">
                            <div class="text-gray-500 dark:text-gray-400 text-sm font-medium uppercase tracking-wider">Mis Aprobados</div>
                            <div class="mt-2 flex items-baseline">
                                <span class="text-3xl font-bold text-gray-900 dark:text-gray-100"><?php echo e($stats['my_approved_count'] ?? 0); ?></span>
                            </div>
                             <div class="mt-1 text-sm text-green-600 font-medium">
                                $<?php echo e(number_format($stats['my_total_reimbursed'] ?? 0, 2)); ?> Total
                            </div>
                        </div>
                    </div>

                <?php else: ?>
                    <!-- Admin / Accountant / User Stats -->
                    
                    <!-- Pending -->
                    <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg border-l-4 border-yellow-500">
                        <div class="p-6">
                            <div class="text-gray-500 dark:text-gray-400 text-sm font-medium uppercase tracking-wider">Pendientes</div>
                            <div class="mt-2 flex items-baseline">
                                <span class="text-3xl font-bold text-gray-900 dark:text-gray-100"><?php echo e($stats['pending_count'] ?? 0); ?></span>
                            </div>
                            <div class="mt-1 text-sm text-yellow-600 font-medium">
                                $<?php echo e(number_format($stats['total_amount_pending'] ?? $stats['total_pending_amount'] ?? 0, 2)); ?>

                            </div>
                        </div>
                    </div>

                    <!-- Corrections (User / Admin) -->
                    <?php if(isset($stats['correction_count']) && $stats['correction_count'] > 0): ?>
                    <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg border-l-4 border-orange-500">
                        <div class="p-6">
                            <div class="text-gray-500 dark:text-gray-400 text-sm font-medium uppercase tracking-wider">Por Corregir</div>
                            <div class="mt-2 flex items-baseline">
                                <span class="text-3xl font-bold text-gray-900 dark:text-gray-100"><?php echo e($stats['correction_count']); ?></span>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>

                    <!-- Approved -->
                    <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg border-l-4 border-green-500">
                        <div class="p-6">
                            <div class="text-gray-500 dark:text-gray-400 text-sm font-medium uppercase tracking-wider">Aprobados</div>
                            <div class="mt-2 flex items-baseline">
                                <span class="text-3xl font-bold text-gray-900 dark:text-gray-100"><?php echo e($stats['approved_count'] ?? 0); ?></span>
                            </div>
                            <div class="mt-1 text-sm text-green-600 font-medium">
                                $<?php echo e(number_format($stats['total_amount_approved'] ?? $stats['total_approved_amount'] ?? 0, 2)); ?>

                            </div>
                        </div>
                    </div>

                    <!-- Rejected -->
                    <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg border-l-4 border-red-500">
                        <div class="p-6">
                            <div class="text-gray-500 dark:text-gray-400 text-sm font-medium uppercase tracking-wider">Rechazados</div>
                            <div class="mt-2 flex items-baseline">
                                <span class="text-3xl font-bold text-gray-900 dark:text-gray-100"><?php echo e($stats['rejected_count'] ?? 0); ?></span>
                            </div>
                        </div>
                    </div>

                <?php endif; ?>

                <!-- Create New Action Card -->
                 <div class="bg-indigo-50 dark:bg-indigo-900 overflow-hidden shadow-sm sm:rounded-lg border border-indigo-200 dark:border-indigo-700 flex flex-col items-center justify-center p-6 hover:bg-indigo-100 dark:hover:bg-indigo-800 transition cursor-pointer" onclick="window.location='<?php echo e(route('reimbursements.create')); ?>'">
                    <div class="text-indigo-600 dark:text-indigo-300 mb-2">
                        <svg class="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
                    </div>
                    <span class="font-bold text-indigo-700 dark:text-indigo-200">Nueva Solicitud</span>
                </div>

            </div>

            <!-- Recent Activity Table -->
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <h3 class="text-lg font-medium leading-6 text-gray-900 dark:text-gray-100 mb-4">Actividad Reciente</h3>
                    
                    <?php if($recentReimbursements->count() > 0): ?>
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                                <thead class="bg-gray-50 dark:bg-gray-700">
                                    <tr>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Folio / Tipo</th>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Solicitante</th>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Fecha</th>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Total</th>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Estatus</th>
                                        <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Acciones</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                                    <?php $__currentLoopData = $recentReimbursements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reimbursement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <div class="text-sm font-medium text-gray-900 dark:text-gray-100">
                                                    <?php echo e($reimbursement->folio ?? Str::limit($reimbursement->uuid, 8) ?? 'S/F'); ?>

                                                </div>
                                                <div class="text-xs text-gray-500 dark:text-gray-400">
                                                    <?php echo e(ucfirst($reimbursement->type)); ?>

                                                </div>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <div class="text-sm text-gray-900 dark:text-gray-100"><?php echo e($reimbursement->user->name ?? 'Usuario'); ?></div>
                                                <div class="text-xs text-gray-500 dark:text-gray-400"><?php echo e($reimbursement->costCenter->code ?? ''); ?></div>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                                                <?php echo e($reimbursement->created_at->format('d/m/Y')); ?>

                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-gray-100">
                                                $<?php echo e(number_format($reimbursement->total, 2)); ?>

                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                                    <?php echo e($reimbursement->status === 'aprobado' ? 'bg-green-100 text-green-800' : ''); ?>

                                                    <?php echo e($reimbursement->status === 'rechazado' ? 'bg-red-100 text-red-800' : ''); ?>

                                                    <?php echo e($reimbursement->status === 'requiere_correccion' ? 'bg-orange-100 text-orange-800' : ''); ?>

                                                    <?php echo e(!in_array($reimbursement->status, ['aprobado', 'rechazado', 'requiere_correccion']) ? 'bg-yellow-100 text-yellow-800' : ''); ?>">
                                                    <?php echo e(ucfirst(str_replace('_', ' ', $reimbursement->status))); ?>

                                                </span>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                                <a href="<?php echo e(route('reimbursements.show', $reimbursement)); ?>" class="text-indigo-600 hover:text-indigo-900 dark:text-indigo-400 dark:hover:text-indigo-300">Ver</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p class="text-gray-500 dark:text-gray-400 text-sm">No hay actividad reciente para mostrar.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\reembolsos\resources\views/dashboard.blade.php ENDPATH**/ ?>